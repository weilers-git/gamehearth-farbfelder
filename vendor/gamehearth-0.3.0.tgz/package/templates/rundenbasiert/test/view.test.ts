import { describe, expect, it } from "vitest";
import { describeTable, joinNames, opponents, revealLine, rowPositions, statusLine, type Players, type Snapshot } from "../client/src/view";

const players: Players = {
  p1: { name: "Anna", connected: true, you: true },
  p2: { name: "Ben", connected: true, you: false },
  p3: { name: "Clara", connected: false, you: false },
};

function snapshot(extra: Partial<Snapshot> = {}): Snapshot {
  return {
    player: "p1",
    players: ["p1", "p2", "p3"],
    public: {
      round: 2,
      scores: { p1: 1, p2: 0, p3: 0 },
      played: { p1: false, p2: true, p3: false },
      lastReveal: { cards: { p1: 17, p2: 4, p3: 9 }, winners: ["p1"] },
      deckSize: 18,
      finished: false,
    },
    me: { cards: [21, 3, 12], chosen: null },
    moves: [
      { type: "play", card: 21 },
      { type: "play", card: 3 },
      { type: "play", card: 12 },
    ],
    version: 4,
    ...extra,
  };
}

describe("Oberfläche", () => {
  it("sagt, was zu tun ist", () => {
    expect(statusLine(snapshot(), players)).toBe("Runde 2 von 5: Wähle eine Karte.");
    const before = snapshot();
    const waiting = snapshot({ moves: [], me: { cards: [21, 3], chosen: 12 }, public: { ...before.public, played: { p1: true, p2: true, p3: false } } });
    expect(statusLine(waiting, players)).toBe("Runde 2 von 5: Du hast die 12 gelegt. Warte auf Clara.");
  });

  it("nennt Sieger und Gleichstand", () => {
    expect(statusLine(snapshot({ result: { winners: ["p1"] } }), players)).toBe("Du gewinnst!");
    expect(statusLine(snapshot({ result: { winners: ["p2", "p3"] } }), players)).toBe("Gleichstand: Ben und Clara.");
  });

  it("zeigt die zuletzt aufgedeckten Karten", () => {
    expect(revealLine(snapshot(), players)).toBe("Aufgedeckt: Du 17, Ben 4, Clara 9. Punkt für dich.");
    expect(describeTable(snapshot(), players)).toContain("Deine Karten: 3, 12, 21.");
  });

  it("ordnet die Mitspieler ab dem eigenen Sitz", () => {
    expect(opponents(snapshot({ player: "p2" }))).toEqual(["p3", "p1"]);
    expect(joinNames(["Anna", "Ben", "Clara"])).toBe("Anna, Ben und Clara");
  });

  it("verteilt eine Reihe mittig und schiebt sie bei wenig Platz zusammen", () => {
    expect(rowPositions(1, 300, 50, 10)).toEqual([150]);
    expect(rowPositions(3, 300, 50, 10)).toEqual([90, 150, 210]);
    const tight = rowPositions(5, 200, 80, 10);
    expect(tight[0]).toBeCloseTo(40);
    expect(tight.at(-1)).toBeCloseTo(160);
  });
});
