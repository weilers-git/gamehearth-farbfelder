export interface DevProblem {
  source: "regeln" | "oberfläche" | "build" | "manifest";
  title: string;
  message: string;
  stack?: string;
  seat?: string;
  move?: unknown;
}

export interface DevMove {
  number: number;
  seat: string;
  action: unknown;
  bot: boolean;
}

export interface SeatView {
  seat: string;
  name: string;
  bot: boolean;
  paused: boolean;
  snapshot: unknown;
}

export interface RealtimeView {
  tick: number;
  running: boolean;
  speed: number;
  inputs: number;
  screen: unknown;
}

export interface SessionView {
  playerCount: number;
  seed: string;
  version: number | undefined;
  result: unknown;
  realtime?: RealtimeView;
  seats: SeatView[];
  state: unknown;
  moves: DevMove[];
  problem: DevProblem | undefined;
  note: string | undefined;
}

export interface DevLog {
  seat: string;
  level: "log" | "info" | "warn" | "error";
  text: string;
}

export interface DevView {
  game: { id: string; name: string; counts: number[]; mode: string; roles: string[] } | undefined;
  session: SessionView;
  client: { version: number; ready: boolean; note: string | undefined };
  problems: DevProblem[];
  logs: DevLog[];
}

const sourceNames: Record<DevProblem["source"], string> = {
  regeln: "Regeln",
  oberfläche: "Oberfläche",
  build: "Bauen",
  manifest: "manifest.json",
};

export function formatProblem(problem: DevProblem): string {
  const lines = [`FEHLER (${sourceNames[problem.source]}): ${problem.title}`, problem.message];
  if (problem.stack !== undefined && problem.stack.trim() !== "") {
    lines.push(problem.stack.replace(/\s+$/, ""));
  }
  if (problem.move !== undefined) {
    lines.push(`Zug von ${problem.seat ?? "?"}: ${JSON.stringify(problem.move)}`);
  }
  return lines.join("\n");
}
