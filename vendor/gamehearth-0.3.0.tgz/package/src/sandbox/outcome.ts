import { maxActionDepth, maxActionLength, maxStateDepth, type GameResult, type InputResult, type MatchError } from "@gamehearth/sdk/platform";

export const maxOutputChars = 256 * 1024;
export const maxOutputBytes = 256 * 1024;
export const maxOutputNodes = 20_000;
export const maxMessageChars = 2000;
export const maxStackChars = 4000;

const errorCodes = new Set(["game-over", "unknown-player", "stale", "not-your-turn", "illegal-move", "game-error"]);
const phases = new Set(["setup", "legalMoves", "apply", "result", "tick"]);

export interface Expected {
  seed: string;
  players: readonly string[];
  version: number;
  tick?: number;
  inputs?: number;
}

export interface GuestMatch {
  format: 1;
  seed: string;
  players: string[];
  state: { public: unknown; players: Record<string, unknown>; secret: unknown };
  randomState: [number, number, number, number];
  version: number;
  tick?: number;
  moves: Record<string, unknown[]>;
  result?: GameResult;
}

export type GuestOutcome = { ok: true; match: GuestMatch; results?: InputResult[] } | { ok: false; error: MatchError };

export type CheckedOutcome = { ok: true; outcome: GuestOutcome } | { ok: false; problem: string };

export function checkOutcome(json: string, expected: Expected): CheckedOutcome {
  const bytes = Buffer.byteLength(json, "utf8");
  if (bytes > maxOutputBytes) {
    return { ok: false, problem: `die Ausgabe hat ${bytes} Bytes, erlaubt sind ${maxOutputBytes}` };
  }
  let value: unknown;
  try {
    value = JSON.parse(json);
  } catch {
    return { ok: false, problem: "die Ausgabe ist kein JSON" };
  }
  if (!isObject(value) || typeof value["ok"] !== "boolean") {
    return { ok: false, problem: "der Ausgabe fehlt das Feld ok" };
  }
  if (value["ok"] === false) {
    return checkError(value["error"], expected);
  }
  const checked = checkMatch(value["match"], expected);
  if (!checked.ok || expected.inputs === undefined || !checked.outcome.ok) {
    return checked;
  }
  const results = checkResults(value["results"], expected.inputs);
  return typeof results === "string" ? { ok: false, problem: results } : { ok: true, outcome: { ...checked.outcome, results } };
}

function checkResults(raw: unknown, count: number): InputResult[] | string {
  if (!Array.isArray(raw) || raw.length !== count) {
    return `results passt nicht zu den ${count} Eingaben`;
  }
  const results: InputResult[] = [];
  for (const entry of raw) {
    if (isObject(entry) && entry["ok"] === true) {
      results.push({ ok: true });
    } else if (isObject(entry) && entry["ok"] === false && typeof entry["code"] === "string" && errorCodes.has(entry["code"]) && entry["code"] !== "game-error" && typeof entry["message"] === "string") {
      results.push({ ok: false, code: entry["code"] as MatchError["code"], message: entry["message"].slice(0, maxMessageChars) });
    } else {
      return "results enthält einen Eintrag in unbekannter Form";
    }
  }
  return results;
}

function checkMatch(match: unknown, expected: Expected): CheckedOutcome {
  if (!isObject(match)) {
    return { ok: false, problem: "match fehlt" };
  }
  if (match["format"] !== 1) {
    return { ok: false, problem: "format ist nicht 1" };
  }
  if (match["seed"] !== expected.seed) {
    return { ok: false, problem: "seed wurde verändert" };
  }
  if (!sameList(match["players"], expected.players)) {
    return { ok: false, problem: "players wurde verändert" };
  }
  if (match["version"] !== expected.version) {
    return { ok: false, problem: `version ist ${String(match["version"])}, erwartet ${expected.version}` };
  }
  if (match["tick"] !== expected.tick) {
    return { ok: false, problem: expected.tick === undefined ? "die Partie hat tick, das Spiel ist aber nicht als Echtzeit gestartet" : `tick ist ${String(match["tick"])}, erwartet ${expected.tick}` };
  }
  const randomState = match["randomState"];
  if (!Array.isArray(randomState) || randomState.length !== 4 || !randomState.every((word) => Number.isInteger(word) && word >= 0 && word <= 0xffffffff)) {
    return { ok: false, problem: "randomState hat keine vier 32-Bit-Wörter" };
  }
  const seats = [...expected.players].sort();
  const state = match["state"];
  if (!isObject(state) || !sameList(Object.keys(state).sort(), ["players", "public", "secret"])) {
    return { ok: false, problem: "state hat nicht genau public, players und secret" };
  }
  if (!isObject(state["players"]) || !sameList(Object.keys(state["players"]).sort(), seats)) {
    return { ok: false, problem: "state.players passt nicht zu den Sitzen" };
  }
  const budget = { nodes: maxOutputNodes };
  const stateShape = inspect(state, maxStateDepth, budget);
  if (stateShape !== undefined) {
    return { ok: false, problem: stateShape === "depth" ? `state ist tiefer als ${maxStateDepth} Ebenen` : tooManyNodes };
  }
  const moves = match["moves"];
  if (!isObject(moves) || !sameList(Object.keys(moves).sort(), seats)) {
    return { ok: false, problem: "moves passt nicht zu den Sitzen" };
  }
  for (const list of Object.values(moves)) {
    if (!Array.isArray(list)) {
      return { ok: false, problem: "moves enthält keine Liste" };
    }
    for (const action of list) {
      const actionShape = inspect(action, maxActionDepth, budget);
      if (actionShape === "nodes") {
        return { ok: false, problem: tooManyNodes };
      }
      if (actionShape === "depth" || JSON.stringify(action).length > maxActionLength) {
        return { ok: false, problem: `ein Zug ist tiefer als ${maxActionDepth} Ebenen oder länger als ${maxActionLength} Zeichen` };
      }
    }
  }
  let winners: string[] | undefined;
  const result = match["result"];
  if (result !== undefined) {
    if (!isObject(result) || !Array.isArray(result["winners"])) {
      return { ok: false, problem: "result hat keine winners" };
    }
    const listed = result["winners"] as unknown[];
    if (new Set(listed).size !== listed.length || !listed.every((winner) => expected.players.includes(winner as string))) {
      return { ok: false, problem: "winners enthält fremde oder doppelte Sitze" };
    }
    winners = listed as string[];
  }
  const clean: GuestMatch = {
    format: 1,
    seed: expected.seed,
    players: [...expected.players],
    state: state as GuestMatch["state"],
    randomState: randomState as GuestMatch["randomState"],
    version: expected.version,
    ...(expected.tick === undefined ? {} : { tick: expected.tick }),
    moves: moves as GuestMatch["moves"],
    ...(winners === undefined ? {} : { result: { winners } }),
  };
  return { ok: true, outcome: { ok: true, match: clean } };
}

function checkError(error: unknown, expected: Expected): CheckedOutcome {
  if (!isObject(error) || typeof error["code"] !== "string" || !errorCodes.has(error["code"]) || typeof error["message"] !== "string") {
    return { ok: false, problem: "der Fehler der Gastfunktion hat eine unbekannte Form" };
  }
  if (error["phase"] !== undefined && (typeof error["phase"] !== "string" || !phases.has(error["phase"]))) {
    return { ok: false, problem: "der Fehler der Gastfunktion nennt eine unbekannte Phase" };
  }
  if (error["player"] !== undefined && !expected.players.includes(error["player"] as string)) {
    return { ok: false, problem: "der Fehler der Gastfunktion nennt einen fremden Sitz" };
  }
  if (error["stack"] !== undefined && typeof error["stack"] !== "string") {
    return { ok: false, problem: "der Fehler der Gastfunktion hat einen ungültigen Stack" };
  }
  const clean: MatchError = {
    code: error["code"] as MatchError["code"],
    message: (error["message"] as string).slice(0, maxMessageChars),
  };
  if (typeof error["phase"] === "string") {
    clean.phase = error["phase"] as NonNullable<MatchError["phase"]>;
  }
  if (typeof error["player"] === "string") {
    clean.player = error["player"];
  }
  if (typeof error["stack"] === "string") {
    clean.stack = error["stack"].slice(0, maxStackChars);
  }
  return { ok: true, outcome: { ok: false, error: clean } };
}

const tooManyNodes = `Zustand und Züge haben zusammen mehr als ${maxOutputNodes} Knoten`;

function inspect(value: unknown, depthLimit: number, budget: { nodes: number }): "depth" | "nodes" | undefined {
  const stack: { value: unknown; depth: number }[] = [{ value, depth: 0 }];
  while (stack.length > 0) {
    const frame = stack.pop() as { value: unknown; depth: number };
    budget.nodes -= 1;
    if (budget.nodes < 0) {
      return "nodes";
    }
    if (frame.value === null || typeof frame.value !== "object") {
      continue;
    }
    if (frame.depth >= depthLimit) {
      return "depth";
    }
    for (const child of Object.values(frame.value)) {
      stack.push({ value: child, depth: frame.depth + 1 });
    }
  }
  return undefined;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function sameList(value: unknown, expected: readonly string[]): boolean {
  return Array.isArray(value) && value.length === expected.length && value.every((item, index) => item === expected[index]);
}
