import { workerData } from "node:worker_threads";
import { forbiddenCalls, heartbeatSlots } from "./heartbeat";

process.setSourceMapsEnabled(true);

const heartbeat = (workerData as { heartbeat?: Int32Array } | undefined)?.heartbeat;

const randomReason = "Zufall kommt aus ctx.random, die Zeit aus ctx.now; nur so lässt sich jede Partie exakt wiederholen.";
const zoneReason = "Das Ergebnis hängt von der Zeitzone des Rechners ab; stattdessen die UTC-Methoden wie getUTCHours() und Date.UTC(...) verwenden.";

function forbidden(call: (typeof forbiddenCalls)[number], label: string = call, reason = randomReason): Error {
  if (heartbeat !== undefined) {
    Atomics.store(heartbeat, heartbeatSlots.forbidden, forbiddenCalls.indexOf(call) + 1);
  }
  return new Error(`${label} ist in Spielen nicht erlaubt. ${reason}`);
}

const RealDate = Date;
const localDateMethods = [
  "getFullYear",
  "getYear",
  "getMonth",
  "getDate",
  "getDay",
  "getHours",
  "getMinutes",
  "getSeconds",
  "getTimezoneOffset",
  "setFullYear",
  "setYear",
  "setMonth",
  "setDate",
  "setHours",
  "setMinutes",
  "setSeconds",
  "toString",
  "toDateString",
  "toTimeString",
  "toLocaleString",
  "toLocaleDateString",
  "toLocaleTimeString",
];

Math.random = () => {
  throw forbidden("Math.random()");
};

RealDate.now = () => {
  throw forbidden("Date.now()");
};

RealDate.parse = () => {
  throw forbidden("Date.parse()", "Date.parse()", zoneReason);
};

for (const name of localDateMethods) {
  Object.defineProperty(RealDate.prototype, name, {
    value: () => {
      throw forbidden("eine Datumsmethode mit Ortszeit", `Date.prototype.${name}()`, zoneReason);
    },
    writable: true,
    configurable: true,
  });
}

globalThis.Date = new Proxy(RealDate, {
  apply() {
    throw forbidden("Date()");
  },
  construct(target, args, newTarget) {
    if (args.length === 0) {
      throw forbidden("new Date() ohne Argument");
    }
    if (args.length > 1 || typeof args[0] !== "number") {
      throw forbidden("new Date(...) mit Text oder mehreren Argumenten", "new Date(...) mit Text oder mehreren Argumenten", zoneReason);
    }
    return Reflect.construct(target, args, newTarget) as object;
  },
});

Object.defineProperty(RealDate.prototype, "constructor", { value: globalThis.Date, writable: true, configurable: true });

globalThis.performance.now = () => {
  throw forbidden("performance.now()");
};

globalThis.crypto.getRandomValues = () => {
  throw forbidden("crypto.getRandomValues()");
};

globalThis.crypto.randomUUID = () => {
  throw forbidden("crypto.randomUUID()");
};
