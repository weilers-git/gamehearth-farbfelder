# gamehearth

Werkzeug für Spiele auf [Gamehearth](https://github.com/weilers-git/gamehearth-starter), einer selbst gehosteten Spieleplattform. Spiele entstehen auch ohne Programmierkenntnisse mit einem KI-Agenten.

| Befehl | Wofür |
|---|---|
| `new` | legt ein neues Spiel aus der Vorlage an |
| `dev` | startet das Spiel lokal mit allen Spielern nebeneinander im Browser |
| `check` | prüft das Spiel wie die Plattform, mit hunderten Bot-Partien |
| `pack` | baut das Spielpaket für einen Katalog |
| `catalog` | pflegt eine `catalog.json` |

## Schnellstart

Voraussetzung ist Node 22 oder neuer.

```bash
npx gamehearth new mein-spiel
cd mein-spiel
npm run dev
```

Dann http://localhost:5180 öffnen. Mit einem KI-Agenten (Claude Code, Cursor, Copilot …) den Ordner öffnen und beschreiben, welches Spiel entstehen soll; die Anleitung für den Agenten liegt dem Spiel als `AGENTS.md` bei.

In einem Spiel- oder Katalog-Repo startet das Werkzeug mit `npx gamehearth <befehl>` oder über die npm-Skripte des Spiels, im Plattform-Monorepo mit `npm run gamehearth -- <befehl>`.

## new

```bash
npx gamehearth new <ordner> [--name "Vier gewinnt"] [--template rundenbasiert|echtzeit] [--no-install] [--no-git]
```

`new` legt in einem neuen oder leeren Ordner ein Spiel aus der Vorlage an und stellt keine Fragen, damit es auch ein Agent aufrufen kann:

- Die `id` kommt aus dem Ordnernamen (`Vier Gewinnt` wird `vier-gewinnt`, Umlaute werden umschrieben). Ein Ordner, aus dem keine gültige `id` entsteht, oder ein Ordner mit Inhalt wird abgelehnt.
- Der Anzeigename kommt aus `--name`, sonst aus der `id`.
- `manifest.json` und `package.json` verlangen das SDK und das Werkzeug in der Version, mit der `new` lief (`^0.1.1`, `^0.3.0`).
- `LICENSE` ist MIT für den Code und CC0 für Grafik; als Inhaber steht `git config user.name` drin, sonst „die Autorinnen und Autoren von <Spiel>“. `AGENTS.md` sagt dem Agenten, vor dem ersten Release nach Lizenz und Namen zu fragen.
- Danach legt `new` ein Git-Repo an (ohne Commit; nicht, wenn der Ordner schon in einem Git-Repo liegt) und führt `npm install` aus. `--no-git` und `--no-install` lassen das weg. Ohne Installation fehlt die `package-lock.json`, die die CI der Vorlage (`npm ci`) braucht: vor dem ersten Push `npm install` ausführen und die Datei mit committen.

Es gibt zwei Vorlagen, beide mit Phaser 4, Vite und TypeScript:

- `rundenbasiert` (der Standard): jeder am eigenen Gerät, mit dem kleinen Beispielspiel **Kartenduell** für 2–4 Spieler (geheimes Deck, verdeckte Hand, alle legen gleichzeitig verdeckt eine Karte), das alle drei Zustandsbereiche, eine verdeckte Wahl ohne Leck, Zufall und das Ende zeigt.
- `echtzeit` (`--template echtzeit`): ein Fernseher zeigt das Feld, die Handys sind Controller. Das Beispiel **Fangen** für 2–6 Spieler zeigt `tick` mit Zeitlimit, Eingaben als gehaltene Richtung, ganzzahlige Bewegung und Abstände, die Rollen `screen` und `controller` mit `connect({ screen: true })`, das Glätten mit `createTimeline` (in `client/src/screen.ts`) und einen Controller mit Steuerkreuz, der auch per Tastatur geht (`client/src/controller.ts`).

Aufbau beider Vorlagen:

| Pfad | Inhalt |
|---|---|
| `AGENTS.md`, `CLAUDE.md` | Anleitung für KI-Agenten (Claude Code liest `CLAUDE.md`, die nur auf `AGENTS.md` verweist) |
| `README.md` | Regeln und Befehle für Menschen |
| `manifest.json`, `LICENSE` | Manifest und Lizenz |
| `src/` | die Regeln (Reducer) |
| `client/` | die Oberfläche mit Phaser 4 (bei `echtzeit` Fernseher und Controller); was sie entscheidet, steht ohne Phaser in `client/src/view.ts` |
| `test/` | Regel- und Oberflächentests mit Vitest |
| `.github/workflows/` | CI für Typen, Tests und `check`; Release-CI, die bei einem Tag `v*` das Paket baut und an ein Release hängt |

Die npm-Skripte der Vorlage: `dev`, `build`, `build:watch`, `test`, `typecheck`, `check` (baut zuerst die Oberfläche) und `pack` (ebenso). `build` schreibt nach `dist/client` (das kommt ins Paket), `build:watch` für `dev` mit Quellkarten nach `dist/dev-client`, damit sich beide nicht in die Quere kommen. `AGENTS.md` verweist für den Vertrag auf die READMEs von SDK und Werkzeug in `node_modules`, damit die Anleitung nach einem Update nicht veraltet.

## dev

```bash
npx gamehearth dev [spielordner] [--build "<befehl>"] [--client <ordner>] [--port 5180] [--host] [--players <n>]
```

In der Vorlage startet `npm run dev` den Befehl mit `--build "npm run build:watch" --client dist/dev-client`. `dev` ist ein kleiner Server nur für die Entwicklung, ohne Login, Lobby und Datenbank:

- **Alle Sitze nebeneinander** unter http://localhost:5180, jeder in einem handygroßen Rahmen. Oben wählt man die Spielerzahl (aus dem Manifest) und startet eine neue Partie. Jeder Sitz hat eine eigene Adresse (`/p1`, `/p2` …) für ein zweites Fenster; mit `--host` ist `dev` auch im WLAN erreichbar, etwa für ein Handy. Die Sitze heißen Anna, Ben, Clara und so weiter, damit Namen unterschiedlicher Länge im Layout auffallen.
- **Wie auf der Plattform:** Die Regeln laufen in derselben QuickJS-Sandbox wie auf dem Server, mit demselben Zeitlimit von 100 ms pro Aufruf (Meldung „Zeitlimit … überschritten“). Was dieses Limit umgeht, etwa ein sehr teurer `sort`, beendet ein Worker mit harter Grenze von 2 Sekunden; danach startet er neu. Die Oberfläche läuft im iframe mit derselben Sandbox und CSP, und `dev` spricht mit ihr über dasselbe Protokoll wie die Plattform. Eine neue Partie lädt die Rahmen neu, wie die Plattform es bei jeder Runde tut. Spieldateien als eigene Seite liefert `dev` wie der Server nicht aus.
- **Bots:** Jeder Sitz lässt sich auf „Bot“ stellen; er zieht dann nach kurzer Pause einen zufälligen erlaubten Zug. Bots bleiben bei einer neuen Partie an. Scheitert der Zug eines Bots am Spielcode, hält dieser Bot an („angehalten“), bis die Regeln neu geladen sind, eine neue Partie beginnt oder man ihn neu einschaltet.
- **Einblick:** Unter jedem Sitz steht aufklappbar der Snapshot, den sein Client bekommt; unten der ganze Zustand samt `secret`, die Züge und der Seed.
- **Echtzeit:** Bei `"mode": "realtime"` rechnet `dev` wie der Server 20 Ticks pro Sekunde. Eingaben warten bis zum nächsten Tick; warten von einem Sitz mehr als 4, verfällt die älteste, und mehr als 30 Eingaben pro Sekunde und Sitz lehnt `dev` wie die Plattform mit `rate-limited` ab. Angehalten (von Hand oder nach einem Fehler) beantwortet `dev` Eingaben sofort und merkt sich je Sitz die letzte für den nächsten Tick, auch für „Ein Tick“. Hat das Spiel die Rolle `screen`, steht vorn ein Rahmen „Fernseher“ im Querformat, mit eigener Adresse `/tv`; die Handys bekommen die Rolle `controller`. Oben gibt es „Anhalten“/„Weiter“, „Ein Tick“ (nur angehalten) und die Zeitlupe (halbe und viertel Geschwindigkeit; die Spielzeit pro Tick bleibt 50 ms, die Rahmen bekommen die längere Tick-Dauer als `tickMs`, damit `createTimeline` weiter weich zeichnet). Bots drücken in jedem Tick mit 20 % Wahrscheinlichkeit eine zufällige erlaubte Eingabe. Wie der Server holt `dev` verspätete Ticks nach (höchstens 200 ms Rückstand), damit die Spielzeit mit der Uhr läuft. Scheitert ein Tick an Zeit, Speicher oder einem Absturz der Sandbox, rechnet `dev` ihn wie der Server einmal nach. Ein Fehler in `tick` hält die Partie an („Tick N ist gescheitert“ oder „Fehler in tick (Tick N)“); „Weiter“ versucht es noch einmal. Unerlaubte Eingaben meldet `dev` als Fehler der Oberfläche nur, wenn sie schon beim Eingang nicht in `snapshot.moves` standen; was erst durch eine frühere Eingabe im selben Tick unerlaubt wird, ist kein Fehler. Ändern sich die Regeln, steht der Takt still, bis sie geladen sind, dann beginnt eine neue Partie mit demselben Seed, denselben Sitzen und Bots, statt nachzuspielen; dieselben Eingaben liefen mit neuen Regeln ohnehin anders. Countdown und Pausen der Plattform (fehlendes Handy, fehlender Fernseher) gibt es in `dev` nicht. Die Liste der Züge zeigt nur die letzten Eingaben.
- **Neu laden heißt nachspielen:** Ändert sich etwas unter `src/` oder `manifest.json`, bündelt `dev` neu und spielt dieselbe Partie aus Seed und Zügen mit dem neuen Code nach. Ist ein Zug nicht mehr erlaubt oder wirft der Code, hält es dort an und sagt, warum; „Neue Partie“ fängt von vorn an. Passt die Spielerzahl nicht mehr zum Manifest, startet eine neue Partie. Lassen sich die Regeln nicht bauen oder nicht in QuickJS laden, läuft die letzte Fassung weiter.
- **Oberfläche neu laden:** Den Client baut der Befehl aus `--build` laufend neu (seine Ausgabe steht mit `[build]` im Terminal). Ausgeliefert wird der Ordner aus `--client`, sonst der aus `manifest.json`. `dev` merkt an der gebauten `index.html`, dass ein neuer Build da ist, und lädt die Rahmen neu; die Partie bleibt stehen.
- **Lesbare Fehler:** Fehler aus der Sandbox (mit Phase, Sitz und Zug) und aus dem iframe (nicht abgefangene Fehler, `console.error`) erscheinen als Banner auf der Seite und als Textblock im Terminal, mit Stelle im Quelltext über die Quellkarten (`src/game.ts:70:17`, `client/src/view.ts:41:11`; Stacks aus Chrome, Firefox und Safari). Ein Knopf kopiert den Text für den Agenten. Ein Fehler bleibt stehen, bis ein Mensch an diesem Tisch wieder erfolgreich zieht; Bot-Züge räumen ihn nicht weg. Derselbe Fehler steht nur einmal hintereinander im Terminal. `console.log` aus der Oberfläche steht mit dem Sitz davor im Terminal, Steuerzeichen werden dabei entfernt. Schickt eine Oberfläche einen Zug, der nicht in ihren `moves` stand, steht das im Terminal.
- **Port:** Standard ist 5180. Ist er belegt, nimmt `dev` den nächsten freien und sagt das; die gültige Adresse steht immer in der Ausgabe. Ein ausdrücklich gewählter `--port` wird nicht ersetzt; ist er belegt, bricht `dev` ab.
- **Wer zugreifen darf:** `dev` hört nur auf `127.0.0.1`. Es antwortet nur auf Anfragen an `localhost`, eine IP-Adresse oder eine Codespaces-Adresse (`*.app.github.dev`), damit eine fremde Webseite es nicht über einen umgebogenen Domainnamen erreicht. Züge und Einstellungen nimmt es nur von der eigenen Seite an (Herkunft gleich dem Host, auch hinter HTTPS). Mit `--host` hört es auf allen Adressen: Dann kann jedes Gerät im selben Netz alle Sitze samt `secret` sehen und steuern und Text ins Terminal schreiben. Nur im eigenen WLAN benutzen. In Codespaces ist `dev` nicht ausprobiert.

Grenzen: Der Zustand lebt nur im Speicher; ein Neustart von `dev` beginnt eine neue Partie. Einen Zug zurücknehmen geht noch nicht. Ein Zug, der auf einen veralteten Stand trifft (etwa weil gerade ein Bot gezogen hat), wird wie auf dem Server als `stale` abgelehnt; man tippt dann noch einmal. Strg+C beendet `dev` samt Build-Prozess; ein zweites Strg+C bricht das Aufräumen ab.

## check

```bash
npx gamehearth check .
```

`check` prüft ein Spiel so, dass Fehler auffallen, bevor jemand damit spielt, und meldet sie so, dass ein KI-Agent sie direkt beheben kann.

1. **Manifest**: Pflichtfelder, Spielerzahl, Rollen, Lizenzen (OSI-Lizenz für Code, CC0/CC-BY/CC-BY-SA für Assets), unbekannte Felder (Tippfehler) und ob die verlangte SDK-Version (`"sdk": "^0.1.1"`) zum vorhandenen SDK passt. Echtzeit-Spiele (`"mode": "realtime"`) brauchen mindestens `"^0.1.1"`, weil ältere Server `tick` nicht kennen. Optional sind `description` (1 bis 200 Zeichen, erscheint im Katalog) und `repository` (`https`-Adresse des Quelltexts). Eine Datei mit BOM, wie sie PowerShell gern schreibt, ist kein Problem.
2. **Client**: Der Ordner aus `"client"` im Manifest (etwa `"dist/client"`) muss gebaut sein, innerhalb des Spielordners liegen und eine `index.html` enthalten. Erlaubt sind höchstens 5000 Dateien und 50 MB, keine Verweise (Symlinks) und nur Dateinamen aus Buchstaben, Ziffern, Leerzeichen und `._@+~()-`. Fehlt der Ordner, meldet `check` das als Fehler und spielt trotzdem alle Partien.
3. **Bauen**: Das Spiel wird aus `src/index.ts` zu einer Datei gebündelt, genauso wie auf dem Server. Eingebunden werden dürfen nur Dateien aus dem Spielordner (Code und JSON-Daten) und das SDK; ein Import wie `../../package.json` oder ein absoluter Pfad bricht mit einer klaren Meldung ab. Node-Module wie `fs` sind in Spielen nicht erlaubt und fallen hier auf, ebenso ein fehlender `export default`.
4. **Bot-Partien**: 200 Partien mit Zufallsbots für jede erlaubte Spielerzahl bis 8, darüber nur Minimum und Maximum. Nach jedem Zug wird gespeichert und geladen. Gemeldet werden Fehler im Spielcode mit Phase, Sitz und Stacktrace. Der Stacktrace zeigt auf die Zeile im Spiel, Zeilen aus SDK und Werkzeug sind herausgefiltert.
5. **Verbotene Funktionen**: `Math.random()`, `Date.now()` (auch über `new Date(0).constructor` oder den Eigenschaftsdeskriptor), `new Date()` ohne Argument, `performance.now()` und `crypto.getRandomValues()`/`randomUUID()` werfen beim Prüfen sofort einen Fehler mit Hinweis auf `ctx.random` und `ctx.now`, auch schon beim Laden des Spiels. Ebenso alles, was von der Zeitzone des Rechners abhängt: Datumsmethoden mit Ortszeit wie `getHours()` oder `toString()`, `Date.parse()` und `new Date` mit Text oder mehreren Argumenten; erlaubt sind `new Date(zahl)`, `Date.UTC(...)` und die UTC-Methoden. Fängt das Spiel diesen Fehler mit `try`/`catch` ab, meldet `check` den Aufruf trotzdem.
6. **Determinismus**: Jede Partie wird aus Seed und Zügen wiederholt, dabei läuft zwischen den Zügen eine zweite Partie mit anderer Spielerzahl im selben Modul. Weicht ein Zustand ab, nennt `check` Zug und Stelle, etwa `match.state.public.count: beim ersten Durchlauf 6, beim Wiederholen 7`. Das findet Variablen außerhalb der Funktionen, auch solche, die sich `setup` merkt: Auf dem Server laufen viele Partien gleichzeitig im selben Modul.
7. **Partien ohne Ende**: Endet eine Partie nach 5.000 Zügen nicht, gibt es eine Warnung, bei der Mehrheit der Partien einen Fehler. Nach drei solchen Partien pro Spielerzahl werden die übrigen übersprungen.
8. **Endlosschleifen**: Die Partien laufen in Worker-Threads. Antwortet Spielcode länger als 3 Sekunden nicht, bricht `check` ab und meldet Phase, Sitz, Zug und Seed. Nach zwei hängenden Partien pro Spielerzahl werden die übrigen übersprungen.
9. **Verdächtiges**: Warnungen, wenn ein erlaubter Zug den Zustand überhaupt nicht ändert (meist fehlt ein `case` in `apply`) und wenn `setup` Zufall benutzt, aber bei jedem Seed denselben Start liefert (meist wurde das Ergebnis von `random.shuffle` verworfen).
10. **Lecks**: nach jedem Zug, siehe unten; bei Echtzeit alle 10 Ticks.
11. **Engine des Servers**: Der Server führt Spiele in QuickJS aus, nicht in Node. Je Spielerzahl spielt `check` deshalb die ersten 10 Partien zusätzlich in derselben Sandbox wie der Server nach (Vorspann, Zeitlimit 100 ms pro Aufruf, Speicherdeckel, Stack-Limit 256 KB) und vergleicht jeden Stand. Nach dem ersten Fehler hört das Nachspielen auf; eine harte Grenze wie im Server-Worker gibt es in `check` nicht, ein sehr langer Aufruf einer eingebauten Funktion hält den Prüflauf also auf. Scheitert eine Partie dort, ist das ein Fehler; typische Ursachen sind Funktionen, die es in QuickJS nicht gibt (`console`, `structuredClone`, `Intl`, `TextEncoder`, `atob`, `URL`), `eval` oder ein zu langsamer Zug. Läuft sie anders, gibt es eine Warnung; meist rechnen `Math.sin`, `Math.exp`, `Math.pow`, `Math.hypot` und Verwandte in den letzten Stellen anders, oder `localeCompare`, `toLocaleString` oder ein inkonsistenter Vergleicher für `sort` verhalten sich anders.

12. **Echtzeit**: Bei `"mode": "realtime"` muss das Spiel `tick` haben, bei anderen Spielen darf es keins haben. Statt Zug für Zug spielt `check` Tick für Tick: In jedem Tick drückt jeder Bot mit 20 % Wahrscheinlichkeit eine zufällige erlaubte Eingabe, dann rechnet `tick`. Gespielt werden 20 Partien pro Spielerzahl, davon 2 zusätzlich in QuickJS. Endet eine Partie nicht innerhalb von 10 Minuten Spielzeit (12.000 Ticks), ist das immer ein Fehler: Echtzeit-Spiele brauchen ein Ende, etwa ein Zeitlimit. Eine einzelne Zeitüberschreitung in QuickJS rechnet `check` wie der Server einmal auf frischer Sandbox nach und meldet sie nur, wenn sie sich wiederholt. Braucht ein Tick samt Eingaben in QuickJS im Schnitt mehr als 10 ms oder in Spitzen mehr als 40 ms, gibt es eine Warnung, weil bei 20 Ticks pro Sekunde alle Räume des Servers in 50 ms passen müssen. Funde nennen statt des Zugs den Tick. Die Warnung „ein erlaubter Zug ändert den Zustand nicht“ entfällt, weil eine Eingabe wie „weiter nach links“ oft nichts ändert.

Die Partien sind selbst reproduzierbar: Gleicher Spielcode ergibt bei jedem Aufruf dieselben Partien. Zu jedem Fund steht der Befehl, mit dem sich genau diese Partie nachspielen lässt, inklusive abweichender Grenzen:

```bash
npx gamehearth check . --players 3 --seed check-3-17
```

Dann zeigt `check` alle Züge der Partie einzeln (bei Echtzeit jede Eingabe mit ihrem Tick), auch bis zu einer Stelle, an der sie hängt, und gibt Ausgaben des Spiels (`console.log`) weiter. Im normalen Prüflauf werden diese Ausgaben verschluckt; der Fortschritt steht auf stderr.

### Lecks

**Züge (Fehler).** Für jeden Spieler vertauscht `check` nach jedem Zug die verdeckten Werte, also die Texte in `secret` und in den Bereichen der anderen Spieler, einschließlich Mengen der Form `{ "herz-7": true }`. Was der Spieler sieht, bleibt dabei gleich. Ändern sich seine erlaubten Züge, hängen sie von Daten ab, die er nicht sehen darf, und verraten sie an seinen Client. Ein Beispiel ist `{ type: "draw", card: "herz-7" }` mit der obersten Karte des Stapels. Eine feste Auswahl wie Schere, Stein, Papier oder alle möglichen Anklagen bei einem Detektivspiel ändert sich nicht und gilt deshalb nicht als Leck, auch wenn die geheime Lösung darin vorkommt.

**Kopien (Warnungen).** Außerdem sucht `check` Werte, die gleichzeitig offen und verdeckt liegen:

| Fund | Beispiel |
|---|---|
| Ein Wert steht gleichzeitig in `public` und in `secret` | `public.next = secret.deck.at(-1)` |
| Ein Wert steht gleichzeitig in `public` und im Bereich eines Spielers | eine Handkarte wird angezeigt, bleibt aber auf der Hand |
| Ein Wert steht im Bereich von p1 und gleichzeitig in `secret` oder bei p2 | p1 bekommt eine Karte von p2 als Kopie |

Als Werte zählen Texte ab 2 Zeichen (außer Sitznamen), Schlüssel von Mengen und kleine Objekte in Listen wie `{ "suit": "herz", "rank": 7 }`, die als Ganzes verglichen werden. Texte, die gerade als Wahlmöglichkeit in Zügen vorkommen, zählen nicht. Aufdecken verschiebt einen Wert normalerweise, statt ihn zu kopieren. Warnungen können trotzdem gewollt sein, etwa eine offen unter dem Stapel liegende Trumpfkarte oder eine Rolle, die ein Seher sehen darf.

Beides sind Heuristiken, keine Garantie. Zahlen und abgeleitete Werte (etwa „die Summe der Karten von p2“ in `public`) erkennen sie nicht.

### Optionen

| Option | Bedeutung |
|---|---|
| `--games <n>` | Partien pro Spielerzahl (Standard 200, bei Echtzeit 20) |
| `--players <n>` | nur diese Spielerzahl prüfen (muss laut Manifest erlaubt sein) |
| `--seed <seed>` | genau eine Partie nachspielen (mit `--players`) |
| `--max-moves <n>` | Züge, nach denen eine Partie als „endet nicht“ gilt (Standard 5000) |
| `--max-seconds <n>` | Spielzeit in Sekunden, nach der eine Echtzeit-Partie als „endet nicht“ gilt (Standard 600) |
| `--timeout <ms>` | Zeit ohne Fortschritt, nach der Spielcode als hängend gilt (Standard 3000) |
| `--quickjs <n>` | Partien pro Spielerzahl, die zusätzlich in QuickJS laufen (Standard 10, bei Echtzeit 2, 0 schaltet ab) |
| `--json` | Bericht als JSON |

Der Rückgabewert ist 0 ohne Fehler, 1 bei mindestens einem Fehler (Warnungen zählen nicht) und 2 bei falschem Aufruf.

### Grenzen

- Spiele ohne Reducer (`server: false`) werden noch nicht gespielt, nur ihr Manifest wird geprüft.
- Bei Echtzeit drücken die Bots zufällig; ein Spiel, das nur endet, wenn jemand gezielt ein Ziel erreicht, braucht deshalb zusätzlich ein Zeitlimit.
- Zufallsbots spielen nicht klug. Fehler, die nur in seltenen, gezielt herbeigeführten Situationen auftreten, können durchrutschen; dagegen helfen eigene Regeltests wie bei Mau-Mau.
- Die Verbote in Node gelten nur beim Prüfen. Auf dem Server sperrt der Vorspann der Sandbox dieselben Funktionen, zusätzlich `eval` und den `Function`-Konstruktor; `instanceof Function` und `Function.prototype` funktionieren dort weiter.

## pack

```bash
npx gamehearth pack . [--out <ordner>]
```

`pack` prüft das Spiel zuerst mit `check` (wie oben, mit allen Partien) und bricht bei Fehlern ab; Warnungen sind erlaubt und werden mitgezählt. Dann baut es das Spielpaket `<id>-<version>.zip` (Standard: `dist/` im Spielordner) und nennt Fassung, Größe und SHA-256. Der Client muss vorher gebaut sein (im Spiel-Repo erledigt das `npm run pack`).

Ein Spielpaket ist ein ZIP mit genau diesen Dateien:

| Datei | Inhalt |
|---|---|
| `manifest.json` | das Manifest, unverändert |
| `game.mjs` | der Reducer, mit esbuild gebündelt wie beim Prüfen (nur Dateien aus dem Spielordner und das SDK), Pflicht bei `server: true` |
| `client/…` | der gebaute Client-Ordner aus `"client"` mit `index.html`, höchstens 5000 Dateien und 50 MB |
| `LICENSE` | Pflicht, höchstens 256 KB |
| `README.md` | optional, höchstens 256 KB |
| `pack.json` | `{ "format": 1, "sdk", "devtool", "warnings" }`: Versionen beim Packen und Zahl der Warnungen von `check`; zählt nicht zum Hash |

Die Fassung heißt wie auf dem Server `<id>@<version>+<hash>`; der Hash läuft über das Manifest, `game.mjs` und alle Client-Dateien. `pack` schreibt das ZIP deterministisch (Einträge sortiert, feste Zeitstempel, immer gleich komprimiert): Derselbe Stand ergibt mit derselben Node-Version dieselbe Prüfsumme. Ganze Pakete sind höchstens 60 MB groß, `game.mjs` höchstens 5 MB.

Gelesen wird ein Paket streng (`inspectPackage`, `readZip`), auf dem Server wie in `catalog add`: nur Deflate oder unkomprimiert, keine Verschlüsselung, kein ZIP64, keine Ordner-Einträge, keine Verweise oder Gerätedateien, keine Pfade mit `..`, `\`, Doppelpunkt oder Steuerzeichen, keine doppelten Namen (auch nicht in anderer Groß- und Kleinschreibung), kein Kommentar, keine Daten vor, zwischen oder nach den Einträgen. Größen und Zahl der Einträge prüft der Leser, bevor er etwas entpackt, und danach die CRC. Alle Fehler eines Pakets kommen auf einmal.

## catalog

```bash
npx gamehearth catalog add catalog.json <paket-adresse> [--name <katalogname>] [--replace]
npx gamehearth catalog check catalog.json [--download]
```

Ein Katalog ist eine `catalog.json` (Format in `docs/design.md` unter „Spielpakete und Kataloge“): Name des Katalogs und pro Spiel `id`, Name, Beschreibung, Repo-Link und Versionen mit SDK-Bereich, Modus, Spielerzahl, Rollen, Lizenz, Größe, Adresse und SHA-256. Ein Katalog hat höchstens 500 Spiele mit je 50 Versionen und ist höchstens 1 MB groß.

`catalog add` lädt das Paket von der Adresse (nur `https`, `http` nur von localhost), prüft es wie der Server und trägt die Version mit Größe und Prüfsumme ein. Die Versionen stehen absteigend sortiert; Name, Beschreibung und Repo-Link kommen aus dem Manifest der neuesten Version. Steht dieselbe Version schon mit anderer Prüfsumme oder Adresse drin, bricht der Befehl ab, außer mit `--replace`. Für einen neuen Katalog braucht es `--name`.

`catalog check` prüft die Form der Datei; mit `--download` lädt es zusätzlich jedes Paket und vergleicht Größe, Prüfsumme, `id` und Version (so prüft die CI des Katalog-Repos).

## Sandbox

Unter `gamehearth/sandbox` liegt der Sandbox-Kern, den Server und `check` gemeinsam nutzen: ein QuickJS-Modul (über `quickjs-emscripten` 0.32.0, fest gewählt, weil die Engine Teil der Spielfassung ist) mit eigenem, gedeckeltem WebAssembly-Speicher pro Sandbox, Vorspann, Gast-Runner und Prüfung der Ausgabe. Wie der Server ihn einsetzt, steht in [packages/server](../server/README.md#sandbox).

## Entwicklung des Werkzeugs

Im Plattform-Monorepo liegt die Vorlage unter `templates/rundenbasiert` und läuft dort mit Tests, Typprüfung und `check` mit. Ein Test prüft, dass `AGENTS.md` nur Dateien, Pfade und npm-Skripte nennt, die es gibt.

Solange etwas nicht auf npm liegt, lässt es sich mit lokal gepackten Tarballs wie von einem Fremden ausprobieren:

```bash
npm pack --pack-destination <ordner>        # in packages/sdk und packages/devtool
npx gamehearth new mein-spiel --local-packages <ordner>
```

`--local-packages` kopiert `gamehearth-sdk-<version>.tgz` und `gamehearth-<version>.tgz` nach `vendor/` und bindet sie per `file:` ein (mit `overrides`, damit es nur eine SDK-Kopie gibt).

`npm run starter -- <ordner>` im Monorepo schreibt den Abzug für das Starter-Repo (`weilers-git/gamehearth-starter`): genau das, was `new` als „Mein Spiel“ erzeugt, mit eigener README für die Startseite.
