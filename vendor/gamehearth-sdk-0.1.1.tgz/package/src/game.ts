import type { Random } from "./random";
import type { AnyGameState, PlayerId } from "./state";

export interface SetupContext {
  players: readonly PlayerId[];
  random: Random;
}

export interface MoveContext extends SetupContext {
  player: PlayerId;
  now: number;
}

export interface TickContext extends SetupContext {
  now: number;
}

export interface GameResult {
  winners: PlayerId[];
}

export interface GameDefinition<S extends AnyGameState, A> {
  setup(ctx: SetupContext): S;
  legalMoves(state: S, player: PlayerId): A[];
  apply(state: S, action: A, ctx: MoveContext): S | void;
  result(state: S): GameResult | undefined;
  tick?(state: S, dt: number, ctx: TickContext): S | void;
}

export function defineGame<S extends AnyGameState, A>(game: GameDefinition<S, A>): GameDefinition<S, A> {
  return game;
}
