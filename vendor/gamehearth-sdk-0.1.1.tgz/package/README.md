# @gamehearth/sdk

Das SDK beschreibt, wie ein Gamehearth-Spiel aufgebaut ist, und führt Partien aus. Ein Multiplayer-Spiel besteht aus vier reinen Funktionen, ein Echtzeit-Spiel aus fünf (dazu `tick`, siehe „Echtzeit“). Alles andere (Sitze, Züge prüfen, Zufall, Fehler abfangen, Sichtbarkeit) übernimmt die Plattform.

Ein neues Spiel samt Vorlage legt das Werkzeug an: `npx gamehearth new mein-spiel` (siehe [gamehearth](https://www.npmjs.com/package/gamehearth)). Dort probiert man es mit `npm run dev` aus und prüft es mit `npm run check`.

## Ein Spiel in einer Datei

```ts
import { defineGame, type GameState, type PlayerId } from "@gamehearth/sdk";

type Public = { revealed: Record<PlayerId, number> };
type PerPlayer = { card: number };
type Secret = { deck: number[] };
type Action = { type: "reveal" };

export default defineGame<GameState<Public, PerPlayer, Secret>, Action>({
  setup({ players, random }) {
    const deck = random.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    const hands: Record<PlayerId, PerPlayer> = {};
    for (const player of players) {
      hands[player] = { card: deck.pop() ?? 0 };
    }
    return { public: { revealed: {} }, players: hands, secret: { deck } };
  },

  legalMoves(state, player) {
    return Object.hasOwn(state.public.revealed, player) ? [] : [{ type: "reveal" }];
  },

  apply(state, action, { player }) {
    state.public.revealed[player] = state.players[player]!.card;
  },

  result(state) {
    const revealed = Object.entries(state.public.revealed);
    if (revealed.length < Object.keys(state.players).length) {
      return undefined;
    }
    const best = Math.max(...revealed.map(([, card]) => card));
    return { winners: revealed.filter(([, card]) => card === best).map(([player]) => player) };
  },
});
```


Spiellogik importiert nur aus `@gamehearth/sdk`. Dort gibt es `defineGame` und die Typen, sonst nichts. Der Client-Teil eines Spiels im Browser importiert aus `@gamehearth/sdk/client`. Werkzeuge für Server, Dev-Tool und Tests liegen getrennt in `@gamehearth/sdk/platform` (siehe unten).

## Der Zustand

Der Zustand hat genau drei Bereiche:

| Bereich | wer sieht ihn | Beispiel |
|---|---|---|
| `public` | alle Spieler und der Bildschirm | Ablagestapel, Punkte, **wer dran ist** |
| `players[sitz]` | nur der Spieler auf diesem Sitz | eigene Handkarten, geheime Rolle |
| `secret` | niemand, nur der Server | Reihenfolge des Decks |

Die Plattform filtert automatisch. Ein Spiel muss nie selbst entscheiden, wer was sehen darf; es muss die Daten nur in den richtigen Bereich legen. Das gilt auch für die Frage, wer gerade dran ist: Die Plattform verrät niemandem, welche anderen Sitze Züge haben. Soll die Oberfläche „Anna ist dran“ zeigen, gehört das in `public`.

Regeln für den Zustand:

- Er enthält nur JSON-Werte: Objekte, Arrays, Strings, endliche Zahlen, `true`/`false`, `null`. Kein `Set`, keine `Map`, kein `Date`, keine Klassen, keine Funktionen, keine Getter. Für Mengen ein Array oder ein Objekt mit `true`-Werten nehmen, für Zeitpunkte eine Zahl.
- Felder mit dem Wert `undefined` verschwinden beim Speichern; das wirkt wie ein fehlendes Feld. In Arrays ist `undefined` nicht erlaubt, dort `null` nehmen. Arrays haben nur Elemente, keine zusätzlichen Eigenschaften.
- Höchstens 100 Ebenen Verschachtelung. Verläufe als Liste speichern, nicht als Kette `{ prev: { prev: … } }`.
- Es gibt keine weiteren Felder neben `public`, `players` und `secret`.
- `players` hat genau einen Eintrag pro Sitz, nicht mehr und nicht weniger.

Objekte im Zustand haben keinen Prototyp. Dadurch sind Schlüssel wie `constructor` oder `toString` ganz normale Daten, etwa in einem Wortspiel. Zum Prüfen, ob ein Schlüssel existiert, `Object.hasOwn(objekt, schlüssel)` oder `schlüssel in objekt` verwenden, nicht `objekt.hasOwnProperty(...)`.

## Sitze

Spieler heißen im Spiel `p1`, `p2`, `p3` … in fester Reihenfolge. Das sind Sitze, keine Personen. Welche Person, welcher Gast oder welcher Bot gerade auf einem Sitz sitzt, regelt die Plattform. Namen gehören deshalb nicht in den Zustand. Die Reihenfolge in `ctx.players` eignet sich als Zugreihenfolge.

Wie viele Sitze es gibt, steht im Manifest des Spiels (`players.min`, `players.max`, `players.counts`). Die Plattform startet eine Partie nur mit einer erlaubten Anzahl; `setup` muss das nicht prüfen.

## Die vier Funktionen

Alle vier sind normale, synchrone Funktionen. `async` oder ein zurückgegebenes Promise meldet die Plattform als Fehler.

### `setup({ players, random })`

Baut den Startzustand. `players` ist die Liste der Sitze.

### `legalMoves(state, player)`

Liefert alle Züge, die dieser Sitz gerade machen darf, als Array. Ein leeres Array heißt: Dieser Sitz kann gerade nicht ziehen.

- Mehrere Sitze dürfen gleichzeitig Züge haben, etwa wenn alle gleichzeitig verdeckt eine Karte wählen.
- Ein Zug ist ein JSON-Wert, üblich ist `{ type: "...", ... }`. Ein Zug darf höchstens 16 384 Zeichen lang und 32 Ebenen tief sein.
- **Ein Zug darf nur enthalten, was dieser Spieler sehen darf.** Die Züge gehen an seinen Client. `{ type: "draw" }` ist richtig, `{ type: "draw", card: "herz-7" }` würde die oberste Karte des Decks verraten.
- Der Zustand ist hier schreibgeschützt. Wer ihn verändern will, bekommt einen Fehler.

### `apply(state, action, ctx)`

Wendet einen Zug an. Die Plattform ruft `apply` **nur mit Zügen auf, die vorher in `legalMoves` standen**. `apply` muss deshalb nicht prüfen, ob ein Zug erlaubt ist.

`apply` darf den übergebenen Zustand direkt verändern und nichts zurückgeben, oder einen neuen Zustand zurückgeben. Beides ist richtig. Frühere Zustände sind dabei immer geschützt.

`ctx` enthält:

| Feld | Inhalt |
|---|---|
| `ctx.player` | der Sitz, der den Zug macht |
| `ctx.players` | alle Sitze |
| `ctx.random` | Zufall, siehe unten |
| `ctx.now` | Zeitpunkt des Zuges in Millisekunden |

### `result(state)`

Liefert `undefined`, solange die Partie läuft, und `{ winners: [...] }`, sobald sie vorbei ist. `winners` enthält Sitze. Ein Unentschieden sind mehrere Gewinner, ein gemeinsam verlorenes Koop-Spiel ist `{ winners: [] }`. Der Zustand ist hier schreibgeschützt.

Wenn niemand mehr Züge hat, muss `result` ein Ergebnis liefern. Sonst würde die Partie für immer hängen, und die Plattform meldet einen Fehler. Bei Echtzeit-Spielen gilt das nicht, weil die Ticks die Partie weitertragen.

## Echtzeit

Ein Echtzeit-Spiel (`"mode": "realtime"` im Manifest, `"sdk": "^0.1.1"` oder neuer) hat eine fünfte Funktion:

### `tick(state, dt, ctx)`

Rechnet die Welt einen Schritt weiter, etwa Figuren bewegen, Zeit herunterzählen, Punkte vergeben. Die Plattform ruft `tick` mit festem Takt auf: 20-mal pro Sekunde, `dt` ist immer 50 (Millisekunden). `ctx` enthält `players`, `random` und `now`. Wie `apply` darf `tick` den Zustand direkt verändern oder einen neuen zurückgeben.

```ts
export default defineGame<State, Action>({
  setup({ players }) { /* … */ },
  legalMoves(state, player) {
    return [{ type: "steer", dir: "left" }, { type: "steer", dir: "right" }, { type: "steer", dir: "none" }];
  },
  apply(state, action, { player }) {
    state.public.steer[player] = action.dir;
  },
  tick(state, dt) {
    state.public.timeLeft -= dt;
    // Figuren nach state.public.steer bewegen …
  },
  result(state) {
    return state.public.timeLeft <= 0 ? { winners: leaders(state) } : undefined;
  },
});
```

So läuft ein Tick:

1. Alle Eingaben, die seit dem letzten Tick angekommen sind, gehen in der Reihenfolge ihrer Ankunft einzeln durch `apply`, jede gegen die dann gültigen `legalMoves`. Eingaben sind ganz normale Züge.
2. Danach rechnet `tick` einen Schritt.
3. Nach jedem Zug und nach dem Tick prüft `result`, ob die Partie vorbei ist. Endet sie durch eine Eingabe, läuft in diesem Schritt kein Tick mehr.

Regeln für Echtzeit-Spiele:

- **Eingaben beschreiben, was gerade gedrückt ist**, nicht jeden Tastendruck. `{ type: "steer", dir: "left" }` beim Drücken und `{ type: "steer", dir: "none" }` beim Loslassen; `tick` bewegt dann, solange gelenkt wird. Schick nur, wenn sich etwas ändert, nicht bei jeder Bewegung des Fingers: Die Plattform nimmt pro Mitglied höchstens 30 Eingaben pro Sekunde an (darüber `rate-limited`), und pro Sitz warten höchstens 4 auf den nächsten Tick; kommt eine fünfte, verfällt die älteste.
- **Während einer Pause** merkt sich die Plattform pro Sitz die letzte Eingabe und wendet sie im ersten Tick danach an; `move` antwortet dann sofort mit `{ ok: true }`. Ein Loslassen während der Pause geht so nicht verloren. Eingaben im Countdown gelten ebenfalls für den ersten Tick.
- **Zeit über Ticks zählen.** Für Zeitlimits und Abklingzeiten `dt` aufsummieren oder Ticks zählen, nicht `ctx.now`. `now` ist die Uhrzeit des Servers und läuft während einer Pause weiter.
- **Jede Partie braucht ein Ende**, meist ein Zeitlimit. `check` meldet Partien, die nach 10 Minuten Spielzeit nicht enden, als Fehler.
- **Der Zustand bleibt klein.** Ein Tick prüft, klont und friert den ganzen Zustand ein, 20-mal pro Sekunde. Ein Raster lieber als Text oder Zahlenliste als als Tausende Objekte. `check` warnt, wenn ein Tick in QuickJS im Schnitt länger als 10 ms braucht.
- `legalMoves` darf in manchen Phasen für alle leer sein (etwa während eines Countdowns im Spiel); die Partie läuft trotzdem weiter.

Was die Plattform dazu tut: Sie sammelt die Eingaben bis zum nächsten Tick, schickt danach jedem Gerät seinen Stand, hält die Partie an, solange ein Sitz oder der Fernseher fehlt, zählt nach einer Pause 3 Sekunden herunter und speichert die Partie alle 10 Sekunden. Ein Fehler in `tick` hält die Partie beim letzten gültigen Stand an. Ein Spiel muss davon nichts wissen.

## Zufall und Zeit

Spiele verwenden **nie** `Math.random()`, `Date.now()` oder `new Date()`. Stattdessen:

| Methode | liefert |
|---|---|
| `random.next()` | Zahl von 0 bis unter 1 |
| `random.int(min, max)` | ganze Zahl von `min` bis einschließlich `max` |
| `random.pick(liste)` | ein Element der Liste |
| `random.shuffle(liste)` | eine gemischte Kopie, die Liste selbst bleibt unverändert |

Zeit kommt aus `ctx.now`. Nur so ist jede Partie aus Seed und Zügen exakt wiederholbar. Das braucht die Plattform für Speichern, Fehlersuche und automatische Tests.

Weitere Regeln aus demselben Grund: `legalMoves`, `apply` und `result` hängen nur von ihren Argumenten ab. Kein Netz, keine Dateien, keine Variablen außerhalb der Funktionen, die sich ändern.

## Fehler, die die Plattform erkennt

Fehler im Spielcode werden abgefangen. Die Partie bleibt im letzten gültigen Zustand, und der Fehler wird mit Phase (`setup`, `legalMoves`, `apply`, `result`, bei Echtzeit `tick`), betroffenem Sitz, Grund und, wenn vorhanden, den ersten Zeilen des Stacktraces gemeldet. Beispiele:

- `apply hat einen Fehler geworfen: Cannot read properties of undefined`
- `apply hat einen ungültigen Zustand geliefert: state.public.used ist ein Set, erlaubt sind nur einfache Objekte, Arrays und Grundwerte`
- `setup hat einen ungültigen Zustand geliefert: state.players hat keinen Eintrag für den Sitz p3`
- `legalMoves für p1 hat einen Fehler geworfen: Cannot assign to read only property 'count' of object`
- `apply darf nicht async sein und kein Promise zurückgeben`
- `result hat ein ungültiges Ergebnis geliefert: winners enthält "anna", das ist kein Sitz dieser Partie (Sitze: p1, p2)`
- `nach apply kann niemand ziehen, aber result meldet kein Ende; die Partie würde für immer hängen`

Endlosschleifen und Speicherfresser fängt nicht das SDK ab, sondern die Sandbox des Servers: Jeder Aufruf von Spielcode darf dort höchstens 100 ms dauern und 32 MB Speicher zusätzlich belegen. Das Dev-Tool `check` findet solche Stellen schon vorher und meldet, wo sie hängen (siehe [packages/devtool](../devtool/README.md)).

## Wo Spielcode läuft

Auf dem Server läuft Spielcode nicht in Node, sondern in QuickJS, einer kleinen JavaScript-Engine in einer Sandbox (siehe [packages/server](../server/README.md#sandbox)). Für Spiele heißt das:

- Es gibt nur die Sprache selbst: kein `console`, kein `structuredClone`, kein `Intl`, kein `TextEncoder`, kein `atob`, kein `URL`, keine Timer, kein Netz, keine Dateien. `Math.random`, `Date.now`, `new Date()` ohne Argument, `eval` und der `Function`-Konstruktor werfen einen Fehler.
- Datumswerte nur in UTC: `new Date(zahl)`, `Date.UTC(...)` und die Methoden mit `UTC` im Namen. Alles, was von der Zeitzone des Rechners abhängt (`getHours`, `toString`, `new Date(2026, 0, 1)`, `new Date("…")`, `Date.parse`), wirft einen Fehler, auch in `check`.
- `Math.sin`, `Math.cos`, `Math.exp`, `Math.log`, `Math.pow`, `Math.hypot`, `Math.tanh` und Verwandte rechnen in den letzten Stellen manchmal anders als im Browser oder in Node. Auf dem Server bleibt jede Partie trotzdem wiederholbar; wer überall exakt gleiche Ergebnisse braucht, rechnet mit ganzen Zahlen oder Grundrechenarten (`+`, `-`, `*`, `/`, `Math.sqrt`, `Math.floor`).
- `localeCompare` und `toLocaleString` kennen kein Gebietsschema; „Äpfel“ sortiert dort hinter „Zebra“. Zum Sortieren von Text einen eigenen Vergleicher schreiben.
- Ein Vergleicher für `sort` muss konsistent negativ, 0 oder positiv liefern; `(a, b) => a > b` ergibt in jeder Engine eine andere Reihenfolge.
- Jeder Zug prüft, klont und friert den ganzen Zustand ein. Mehrere zehntausend kleine Objekte im Zustand sprengen das Zeitlimit; lange Texte sind billig. Die Ausgabe eines Zugs darf höchstens 256 KB (in UTF-8) groß sein, und Zustand und erlaubte Züge zusammen höchstens 20 000 Knoten haben (jedes Objekt, jede Liste und jeder einzelne Wert zählt).

`check` spielt deshalb einige Partien zusätzlich in QuickJS nach und meldet, wenn sie dort anders laufen oder scheitern.

`tick` läuft wie alle anderen Funktionen in QuickJS und muss in dieselben Grenzen passen; bei 20 Ticks pro Sekunde sollte ein Tick samt Eingaben aber weit unter den 100 ms bleiben (siehe „Echtzeit“).

## Im Browser: `@gamehearth/sdk/client`

Der Client-Teil eines Spiels läuft in einem abgeschotteten iframe der Plattform. Er kann weder `fetch` noch WebSocket nach außen nutzen und kennt weder Server noch Token; alles läuft über die Plattform. Spiele nutzen auch kein WebRTC (das sperrt der Browser nicht, ist aber nicht Teil des Vertrags).

```ts
import { connect } from "@gamehearth/sdk/client";
import type { MauMauAction, MauMauState } from "../src/game";

const game = await connect<MauMauState, MauMauAction>();

game.onUpdate(({ snapshot, players, online }) => {
  // snapshot: public, me, moves, version, result (siehe playerSnapshot)
  // players.p1: { name: "Anna", connected: true, you: false }
  render(snapshot, players);
});

const result = await game.move({ type: "play", card: "herz-7" });
if (!result.ok) {
  // result.code: illegal-move, not-your-turn, stale, game-over, offline, timeout …
}
```

| Teil | Bedeutung |
|---|---|
| `connect()` | meldet sich bei der Plattform und wartet auf den ersten Stand (höchstens 10 Sekunden); läuft das Spiel nicht in Gamehearth, wird die Promise abgelehnt |
| `game.seat` | der eigene Sitz, etwa `"p2"` |
| `game.current` | der zuletzt empfangene Stand |
| `game.onUpdate(f)` | ruft `f` sofort mit dem aktuellen Stand und danach bei jeder Änderung auf; gibt eine Funktion zum Abmelden zurück |
| `game.move(zug)` | schickt einen Zug; die Antwort ist `{ ok: true }` oder `{ ok: false, code, message }` und kommt höchstens nach 15 Sekunden (sonst `timeout`) |

- Der neue Stand nach einem Zug kommt über `onUpdate`, nicht als Antwort von `move`. Antwortet `move` mit `{ ok: true }`, ist er schon angekommen; `game.current` zeigt dann den Stand nach dem Zug.
- `move` schickt die `version` des zuletzt empfangenen Stands mit. Hat sich die Partie inzwischen geändert, lautet die Antwort `stale`, und der neue Stand ist schon unterwegs. Ein Spiel muss darauf nicht reagieren.
- Namen gibt es nur über `players`, nie im Zustand. `connected` sagt, ob jemand gerade verbunden ist; `online` sagt, ob das eigene Gerät den Server erreicht.
- Verbindungsabbrüche, Fehler im Spielcode auf dem Server und Drosselung zeigt die Plattform selbst an.
- Wer gerade dran ist, steht wie immer im Zustand des Spiels (`public`).

### Rollen: Spieler, Controller und Fernseher

Jedes Gerät hat eine Rolle (`game.role`), die die Plattform aus dem Manifest vergibt:

| Rolle | Gerät | bekommt |
|---|---|---|
| `player` | jeder am eigenen Gerät | Sitz, eigenen Stand (`me`), eigene Züge |
| `controller` | Handy als Controller, das Feld zeigt der Fernseher | wie `player` |
| `screen` | Fernseher, gekoppelt an den Raum | nur Öffentliches: `players`, `public`, `version`, `tick`, `result`; kein Sitz, keine Züge |

Ein Spiel mit Fernseher (Rolle `screen` im Manifest) ruft `connect({ screen: true })` auf und unterscheidet danach:

```ts
import { connect, createTimeline, lerp } from "@gamehearth/sdk/client";

const game = await connect<State, Action>({ screen: true });
if (game.role === "screen") {
  // Feld zeichnen; game.current.snapshot ist ein ScreenSnapshot ohne me und moves
} else {
  // Controller: game.seat, game.move(…)
}
```

Ohne `screen: true` lehnt `connect` die Rolle Fernseher mit einer Fehlermeldung ab; rundenbasierte Spiele ohne Fernseher ändern nichts.

### Glätten bei Echtzeit

Der Server schickt 20 Stände pro Sekunde, ein Bildschirm zeichnet 60 oder mehr Bilder. `createTimeline` puffert die Stände mit ihrer Tick-Nummer und liefert für jedes Bild zwei Stände und einen Mischwert:

```ts
const timeline = createTimeline(game);

function draw() {
  const frame = timeline.frame();
  if (frame !== undefined) {
    const x = lerp(frame.from.public.x, frame.to.public.x, frame.alpha);
    // zeichnen …
  }
  requestAnimationFrame(draw);
}
requestAnimationFrame(draw);
```

| Teil | Bedeutung |
|---|---|
| `createTimeline(game, { delayMs? })` | hört auf `game.onUpdate`; zeigt standardmäßig zwei Ticks (100 ms) hinter dem neuesten Stand, damit fast immer ein Stand davor und einer danach da ist. Schickt die Plattform eine andere Tick-Dauer (`tickMs` im Update, etwa in der Zeitlupe von `dev`), rechnet der Puffer damit |
| `timeline.frame(now?)` | `{ from, to, alpha }` mit `alpha` von 0 bis 1, oder `undefined` vor dem ersten Stand; kommt nichts nach (Pause, Ende), sind `from` und `to` der neueste Stand |
| `timeline.latest` | der neueste Stand |
| `timeline.dispose()` | meldet sich wieder ab |
| `lerp(a, b, alpha)` | mischt zwei Zahlen |

Gemischt werden nur Werte, die sich gleichmäßig ändern, etwa Positionen. Punkte, Zähler, Indizes und alles, was springt, kommen aus `frame.to`. Springt die Tick-Nummer zurück (neue Runde), beginnt der Puffer neu; nach einer Pause richtet er sich neu aus.

**Protokoll.** Unter `connect` liegt `postMessage` mit Nachrichten der Form `{ gamehearth: 1, type, … }`. Das Spiel schickt `ready` und `move` (`id`, `action`, `expectedVersion`), die Plattform `update` (`seat`, `role`, `snapshot`, `players`, `online`, wahlweise `tickMs`, wenn ein Tick gerade nicht 50 ms dauert) und `result` (`id`, `ok`, bei Fehlern `code` und `message`). `role` ist `player`, `controller` oder `screen`; ein Fernseher hat `seat: null`. Echtzeit-Stände tragen `snapshot.tick`. Beide Seiten werfen Nachrichten aus anderen Fenstern und in fremder Form weg. Für die Plattform prüft `parseGameMessage` aus `@gamehearth/sdk/platform` Form, Größe und JSON-Regeln jedes Zugs wie der Server.

## Für die Plattform: `@gamehearth/sdk/platform`

Diese Funktionen benutzen Server, Dev-Tool und Tests, nicht die Spiele selbst.

| Funktion | Zweck |
|---|---|
| `createMatch(game, { playerCount, seed })` | startet eine Partie |
| `applyMove(game, match, { player, action, now, expectedVersion? })` | wendet einen Zug an |
| `stepMatch(game, match, { inputs, now, dt })` | ein Echtzeit-Schritt: die Eingaben `{ player, action }` in Reihenfolge, dann `tick`; liefert `{ ok: true, match, results }` oder `{ ok: false, error }`. `results` hat ein Ergebnis pro Eingabe in derselben Reihenfolge, jeweils `{ ok: true }` oder `{ ok: false, code, message }`, also ohne das Feld `error` wie bei `applyMove` |
| `tickRate`, `tickMs` | der feste Takt: 20 Ticks pro Sekunde, 50 ms |
| `playerSnapshot(match, player)` | was der Client eines Sitzes bekommt |
| `screenSnapshot(match)` | was ein Bildschirm (Rolle `screen`) bekommt |
| `isPlayerCountAllowed`, `allowedPlayerCounts`, `validatePlayerCountSpec` | Spielerzahl aus dem Manifest |
| `parseGameMessage`, `parsePlatformMessage` | prüfen Nachrichten zwischen Plattform und Spiel-iframe (siehe oben) |

`createMatch` und `applyMove` liefern `{ ok: true, match }` oder `{ ok: false, error }`. `error` hat `code` und `message`, bei `game-error` zusätzlich `phase` und, soweit bekannt, `player` und `stack`. Die Codes:

| Code | Bedeutung |
|---|---|
| `game-over` | die Partie ist schon vorbei |
| `unknown-player` | diesen Sitz gibt es nicht |
| `stale` | der Zug bezieht sich auf einen alten Stand (`expectedVersion`) |
| `not-your-turn` | der Sitz hat gerade keine Züge |
| `illegal-move` | der Zug steht nicht in den erlaubten Zügen, ist kein JSON-Wert oder ist zu groß |
| `game-error` | der Spielcode hat einen Fehler gemacht |

Fehler der Plattform selbst sind dagegen Ausnahmen: eine ungültige Spielerzahl, ein leerer Seed, ein `now`, das keine endliche Zahl ist, oder eine Partie in einem unbekannten Format.

Eine Partie (`Match`) ist reines JSON und kann so gespeichert werden. Sie enthält Formatversion, Seed, Sitze, Zustand, die erlaubten Züge pro Sitz, den Zustand des Zufallsgenerators, eine Versionsnummer, bei Echtzeit die Zahl der Ticks (`tick`) und gegebenenfalls das Ergebnis. Die erlaubten Züge werden nach jeder Änderung einmal berechnet und gespeichert; Snapshots führen deshalb keinen Spielcode aus. `version` steigt mit jeder Änderung des Zustands. Ein Client schickt sie als `expectedVersion` mit, damit ein doppelter Klick oder eine veraltete Ansicht keinen falschen Zug auslöst.

Ein `playerSnapshot` enthält `player`, `players`, `public`, `me` (den eigenen Bereich), `moves` (die eigenen Züge), `version`, bei Echtzeit `tick` und gegebenenfalls `result`. `players` ist hier die Liste der Sitze in derselben Reihenfolge wie `ctx.players` in den Regeln; das gleichnamige `players` eines Updates im Client ist dagegen ein Objekt mit Namen pro Sitz. Ein `screenSnapshot` enthält `players`, `public`, `version`, bei Echtzeit `tick` und gegebenenfalls `result`.

`createMatch` erkennt ein Echtzeit-Spiel an `tick` und beginnt mit `tick: 0`. Ein Echtzeit-Schritt erhöht `version` und `tick` um genau 1, egal wie viele Eingaben er enthält. Eine Eingabe, die nicht erlaubt ist, bekommt in `results` ihren Fehlercode, ohne den Schritt aufzuhalten; ein Fehler im Spielcode (`game-error`, auch Phase `tick`) lässt den ganzen Schritt scheitern.

**Seeds** erzeugt der Server zufällig, mindestens 128 Bit (etwa 32 Hex-Zeichen aus einem kryptografischen Zufallsgenerator). Seed und Zufallszustand verlassen nie den Server; die Snapshots enthalten sie nicht. Der Zufallsgenerator (sfc32 mit 128 Bit Zustand) ist schnell und reproduzierbar, aber nicht kryptografisch sicher. Gegen Ausprobieren aller Zustände ist er zu groß, gegen gezielte Kryptoanalyse ist er nicht gebaut.

## Noch nicht enthalten

- Vorhersage mit Rollback bei Echtzeit; das Glätten zeigt die Welt bewusst etwa 100 ms hinter dem Server.
- Ein Takt pro Spiel; alle Echtzeit-Spiele laufen mit 20 Ticks pro Sekunde.
- Zeitlimits pro Zug.
- Spiele mit sehr vielen möglichen Zügen: `legalMoves` zählt jeden Zug einzeln auf. Für Karten- und Brettspiele reicht das; bei riesigen Zugmengen braucht es später eine andere Prüfung.
- Prüfung der JSON-Regeln schon beim Tippen (auf Typebene). Bisher erkennt erst die Laufzeit Verstöße, dafür mit genauer Meldung.
